create function percentages() returns TABLE("SourceIPv4Address" inet, "DestinationIPv4Address" inet, pct numeric)
  language plpgsql
as
$$ #variable_conflict use_column
begin

  return query with pairs("SourceIPv4Address", "DestinationIPv4Address") as (
    select "SourceIPv4Address",
           "DestinationIPv4Address"
    from "Flows"
    )
    select "SourceIPv4Address",
           "DestinationIPv4Address",
           round((count(pairs) / sum(count(pairs)) over ()), 5
             ) * 100 as pct
    from pairs
    group by pairs."SourceIPv4Address", pairs."DestinationIPv4Address"
    order by pct desc;

end;
$$;

alter function percentages() owner to postgres;

