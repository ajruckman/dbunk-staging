create view "Talker_Percentages" as
  WITH pairs("SourceIPv4Address", "DestinationIPv4Address") AS (
    SELECT "Flows"."SourceIPv4Address",
           "Flows"."DestinationIPv4Address"
    FROM "Flows"
    )
    SELECT pairs."SourceIPv4Address",
           pairs."DestinationIPv4Address",
           (round(((count(pairs.*))::numeric / sum(count(pairs.*)) OVER ()), 5) * (100)::numeric) AS pct
    FROM pairs
    GROUP BY pairs."SourceIPv4Address", pairs."DestinationIPv4Address"
    ORDER BY (round(((count(pairs.*))::numeric / sum(count(pairs.*)) OVER ()), 5) * (100)::numeric) DESC;

alter table "Talker_Percentages"
  owner to "DbunkMgr";

