create view "IP_Percentages" as
SELECT "Flows"."IpVersion",
       (round(((count("Flows"."IpVersion"))::numeric / sum(count("Flows"."IpVersion")) OVER ()), 5) *
        (100)::numeric) AS pct
FROM "Flows"
GROUP BY "Flows"."IpVersion";

alter table "IP_Percentages"
  owner to "DbunkMgr";

