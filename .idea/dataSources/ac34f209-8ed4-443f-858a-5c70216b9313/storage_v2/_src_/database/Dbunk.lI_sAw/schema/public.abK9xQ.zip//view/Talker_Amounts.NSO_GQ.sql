create view "Talker_Amounts" as
SELECT "Flows"."SourceIPv4Address",
       "Flows"."DestinationIPv4Address",
       pg_size_pretty(sum("Flows"."OctetDeltaCount")) AS total
FROM "Flows"
GROUP BY "Flows"."SourceIPv4Address", "Flows"."DestinationIPv4Address"
ORDER BY (sum("Flows"."OctetDeltaCount")) DESC;

alter table "Talker_Amounts"
  owner to "DbunkMgr";

